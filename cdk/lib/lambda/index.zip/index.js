const AWS = require('aws-sdk');
const uuid = require("uuid")
const docClient = new AWS.DynamoDB.DocumentClient();


exports.handler = async (event, context) => {
    context.callbackWaitsForEmptyEventLoop = false;
    
    if(event.httpMethod === "POST"){
      console.log("here")
      
      const params = {TableName:'scholardb', Item:{'id':uuid.v1(), ...JSON.parse(event.body)}}
      console.log(params)
      
      const result = await docClient.put(params).promise()
      console.log(result)
    }
    
    const response = {
      statusCode: 200,
      headers: {
      "Access-Control-Allow-Origin" : "*", // Required for CORS support to work
      "Access-Control-Allow-Credentials" : true ,// Required for cookies, authorization headers with HTTPS 
      "Access-Control-Allow-Headers": "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"

    },
      body: JSON.stringify(event),
    };
    return response;
  };